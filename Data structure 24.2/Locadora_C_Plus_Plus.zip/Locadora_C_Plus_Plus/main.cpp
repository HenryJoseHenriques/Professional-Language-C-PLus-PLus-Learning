#include "portal.cpp"
#include <iostream>
using namespace std;

int main()
{
    menuLocadora();
}