#include <iostream>
#include "menu.cpp"
using namespace std;

int main(){
    menu();
    return 0;
}